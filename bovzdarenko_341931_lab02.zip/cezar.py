from collections import Counter

def caesar_decrypt(data, k):
    return bytes((b - k) % 256 for b in data)

def ocena(tekst):
    dobre = sum(1 for b in tekst if b == 32 or 65 <= b <= 90 or 97 <= b <= 122)
    return dobre / len(tekst)

with open("cezar.bin", "rb") as f:
        data = f.read()
        print(data, len(data))
szyfr = data

kandydaci = []
for k in range(256):
    tekst = caesar_decrypt(szyfr, k)
    kandydaci.append((ocena(tekst), k, tekst))
kandydaci.sort(reverse=True)
wynik5 = []
for i in range(5):
     wynik5.append(kandydaci[i])
wynik5.reverse()
for wynik, k, tekst in wynik5:
    print(f"k={k:3d} ocena={wynik:.2f} {tekst!r}")
    if k == 233:
        with open("cezar.txt", "w") as f:
            f.write(str(wynik5[0]))