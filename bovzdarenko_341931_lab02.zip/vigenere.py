def vig_encrypt(data, key):
    wynik = bytearray()
    for i, b in enumerate(data):
        k = key[i % len(key)]
        wynik.append((b + k) % 256)
    return bytes(wynik)
def vig_decrypt(data, key):
    return bytes((b - key[i % len(key)]) % 256 for i, b in enumerate(data))

with open("tekst_pl.txt", "rb") as f:
        data = f.read()
        print(data)
szyfr = vig_encrypt(data, b"ZAMEK")
with open("vigenere.bin", "wb") as f:
    f.write(szyfr)

with open("vigenere.bin", "rb") as f:
        data = f.read()
        #print(data, len(data))
print("--------------------------------------")
szyfr = data
print(vig_decrypt(szyfr, b"ZAMEK"))

print("ZADANIE 2.2")
bra = b"BRAMABRAMABRAMA"
szyfr = vig_encrypt(bra, b"SZYFR")
info = [szyfr.hex()[i:i+5] for i in range(0, len(szyfr), 5)]
print(info)
szyfr = vig_encrypt(szyfr, b"KOD")
info = [szyfr.hex()[i:i+5] for i in range(0, len(szyfr), 5)]
print(info)