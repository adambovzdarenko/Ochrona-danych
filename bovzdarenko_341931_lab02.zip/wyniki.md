Zadanie 1.
Przesunięcie k = 233

Wyjaśnij, dlaczego sama entropia histogramu wartości
0–255 nie rozstrzygnie, które przesunięcie jest poprawne:

Dlatego że:
1. entropia zależy od histogramu, a nie kolejności - w wyniku czego "ala ma kota" i "aaaaklmot" mają taką samą ocenę
2. U "Cezara" wszystkie 256 wyników mają taką samą histogramę tylko przesuniętą
3. Bezsensowny tekst może mieć mniejszą entropię

Zadanie 2.
W 2–3 zdaniach wyjaśnij, dlaczego w jednym przypadku powtarzają się całe pięciobajtowe fragmenty
kryptogramu, a w drugim nie. Odnieś to do położenia powtarzanego tekstu względem klucza i informacji
widocznej dla atakującego:

Dlatego że długość powtarzającego się tekstu i pierwszego klucza jest taka sama, jak
BRAMABRAMABRAMA
SZYFRSZYFRSZYFR
gdzie BRAMA i SZYFR nakłądają się.
wynik:
['95ac9', 'a9393', '95ac9']
Dystans pomiędzy powatrającymi się elementami wyniku jest równy 10. Co oznacza, że długość klucza jest równa 10 albo 5.
W wyniku takiej manipulacji atakujący ma możliwość zdobycia informacji niezbędnej do deszyfrowania tekstu.
